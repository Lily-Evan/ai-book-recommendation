async function handler({
  title,
  author,
  description,
  language,
  publication_year,
  isbn,
  image_url,
  source_url,
}) {
  try {
    if (!title || !author || !language) {
      return { error: "Title, author, and language are required" };
    }

    const result = await sql(
      `INSERT INTO books (title, author, description, language, publication_year, isbn, image_url, source_url) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
       RETURNING *`,
      [
        title,
        author,
        description,
        language,
        publication_year,
        isbn,
        image_url,
        source_url,
      ]
    );

    return { book: result[0] };
  } catch (error) {
    return { error: "Failed to add book" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}