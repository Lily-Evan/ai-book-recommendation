async function handler({
  query = "new books 2024",
  language = "en",
  maxResults = 10,
}) {
  try {
    const searchQuery = `${query} ${language === "el" ? "βιβλία" : "books"}`;

    const searchResponse = await fetch(
      `/integrations/google-search/search?q=${encodeURIComponent(searchQuery)}`
    );
    const searchData = await searchResponse.json();

    if (searchData.status !== "success" || !searchData.items) {
      return { error: "Failed to search for books" };
    }

    const addedBooks = [];
    const errors = [];

    for (let i = 0; i < Math.min(searchData.items.length, maxResults); i++) {
      const item = searchData.items[i];

      try {
        const bookData = extractBookInfo(item);

        if (bookData.title && bookData.author) {
          const existingBooks = await sql(
            "SELECT id FROM books WHERE LOWER(title) = LOWER($1) AND LOWER(author) = LOWER($2)",
            [bookData.title, bookData.author]
          );

          if (existingBooks.length === 0) {
            const result = await sql(
              `INSERT INTO books (title, author, description, language, publication_year, isbn, image_url, source_url) 
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
               RETURNING *`,
              [
                bookData.title,
                bookData.author,
                bookData.description,
                language,
                bookData.publication_year,
                bookData.isbn,
                bookData.image_url,
                item.link,
              ]
            );

            addedBooks.push(result[0]);
          }
        }
      } catch (bookError) {
        errors.push(`Failed to process book: ${item.title}`);
      }
    }

    return {
      success: true,
      addedBooks,
      totalFound: searchData.items.length,
      totalAdded: addedBooks.length,
      errors: errors.length > 0 ? errors : undefined,
    };
  } catch (error) {
    return { error: "Failed to search and add books" };
  }
}

function extractBookInfo(searchItem) {
  const title = searchItem.title.replace(/[^\w\s\-:.,!?]/g, "").trim();
  const snippet = searchItem.snippet || "";

  let author = "";
  let description = snippet;
  let publication_year = null;
  let isbn = null;
  let image_url = null;

  const authorMatch =
    snippet.match(/by\s+([^,.\n]+)/i) ||
    snippet.match(/author[:\s]+([^,.\n]+)/i) ||
    title.match(/by\s+([^,.\n]+)/i);
  if (authorMatch) {
    author = authorMatch[1].trim();
  }

  const yearMatch = snippet.match(/\b(19|20)\d{2}\b/);
  if (yearMatch) {
    publication_year = parseInt(yearMatch[0]);
  }

  const isbnMatch = snippet.match(/ISBN[:\s]*(\d{10}|\d{13})/i);
  if (isbnMatch) {
    isbn = isbnMatch[1];
  }

  if (!author && title.includes(" - ")) {
    const parts = title.split(" - ");
    if (parts.length >= 2) {
      author = parts[1].trim();
    }
  }

  return {
    title: title.substring(0, 255),
    author: author.substring(0, 255),
    description: description.substring(0, 1000),
    publication_year,
    isbn,
    image_url,
  };
}
export async function POST(request) {
  return handler(await request.json());
}